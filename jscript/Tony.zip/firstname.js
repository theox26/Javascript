function getFirstName(contact) {

var arry= contact.split(" ");
var fName = arry[0];

return fName;
}
